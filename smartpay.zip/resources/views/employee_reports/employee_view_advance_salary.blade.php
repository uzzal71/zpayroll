@extends('layouts.app')

@section('content')

<div class="row">
    <div class="col-lg-10 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0 h6">Employee Advance Salary View</h5>
            </div>
            <div class="card-body">
                Comming soon
            </div>
        </div>
    </div>
</div>

@endsection
