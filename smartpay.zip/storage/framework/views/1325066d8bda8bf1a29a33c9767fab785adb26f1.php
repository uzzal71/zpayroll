

<?php $__env->startSection('content'); ?>

<div class="row">
    <!-- Select Box -->
    <div class="col-lg-6 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0 h6">Filters</h5>
            </div>
            <div class="card-body">

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Month</label>
                        <div class="col-md-9">
                            <select name="month" id="month" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                <option value="0">Select Month</option>
                                <option value="01">January</option>
                                <option value="02">February</option>
                                <option value="03">March</option>
                                <option value="04">April</option>
                                <option value="05">May</option>
                                <option value="06">June</option>
                                <option value="07">July</option>
                                <option value="08">August</option>
                                <option value="09">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Year</label>
                        <div class="col-md-9">
                            <select name="year" id="year" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                <option value="0">Select Year</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Department</label>
                        <div class="col-md-9">
                            <select class="form-control aiz-selectpicker" name="department_id" id="department_id" data-live-search="true" required>
                                <option value="">Select Department</option>
                                <option value="all">All</option>
                                <?php $__currentLoopData = \App\Models\Department::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"><?php echo e($department->department_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Designation</label>
                        <div class="col-md-9">
                            <select class="form-control aiz-selectpicker" name="designation_id" id="designation_id" data-live-search="true" required>
                                <option value="">Select Designation</option>
                                <option value="all">All</option>
                                <?php $__currentLoopData = \App\Models\Designation::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($designation->id); ?>"><?php echo e($designation->designation_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Schedule</label>
                        <div class="col-md-9">
                            <select class="form-control aiz-selectpicker" name="schedule_id" id="schedule_id" data-live-search="true" required>
                                <option value="">Select Schedule</option>
                                <option value="all">All</option>
                                <?php $__currentLoopData = \App\Models\Schedule::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($schedule->id); ?>"><?php echo e($schedule->schedule_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Status</label>
                        <div class="col-md-9">
                            <select name="status" id="status" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                <option value="">Select Status</option>
                                <option value="all">All</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>

               
            </div>
        </div>
    </div>
    <!-- Select Box -->

    <!-- Employee Box -->
    <div class="col-lg-6 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0 h6">Employee List <span class="badge badge-warning" id="select-box"></span></h5>
            </div>
            <div class="card-body">
                <div class="FixedHeightContainer">
                <div id="result" class="Content">
                    
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Employee Box -->
</div>


<div class="row">
    <div class="col-12 text-center">
        <button type="button" class="btn btn-success mt-2 mb-4" id="monthly_payslip_report">Submit</button>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $( "#department_id" ).change(function() {get_update_employee_list()});
        $( "#designation_id" ).change(function() {get_update_employee_list()});
        $( "#schedule_id" ).change(function() {get_update_employee_list()});
        $( "#status" ).change(function() {get_update_employee_list()});

        function get_update_employee_list() {
            var department_id = document.getElementById('department_id').value;
            var designation_id = document.getElementById('designation_id').value;
            var schedule_id = document.getElementById('schedule_id').value;
            var status = document.getElementById('status').value;

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:"POST",
                url:'<?php echo e(route('ajax.get_employee')); ?>',
                data: {
                    'department_id': department_id,
                    'designation_id': designation_id,
                    'schedule_id': schedule_id,
                    'status': status
                },
                success: function(data) {
                    $('#result').html(data.output);
                }
            });
        }

        for(var i = 0; i < 1000; i++) {
            (function(index) {
                setTimeout(function() {
                    var check = $('#result').find('input[type=checkbox]:checked').length;
                    $('#select-box').html(check);
                }, index*1000);
            })(i);
        }
    });

    $(document).on("change", ".check-all", function() {
        if(this.checked) {
            // Iterate each checkbox
            $('.check-one:checkbox').each(function() {
                this.checked = true;
            });
        } else {
            $('.check-one:checkbox').each(function() {
                this.checked = false;
            });
        }
    });

    $(document).ready(function() {
        $('#monthly_payslip_report').click(function() {
            var month = document.getElementById('month').value;
            var year = document.getElementById('year').value;
            var employee_id = [];
            $.each($("input[type=checkbox].check-one:checked"), function(){
                employee_id.push($(this).val());
            });

            // validation
            if (month == '') {
                AIZ.plugins.notify('danger', 'Please select month');
                return false;
            }

            if (year == '') {
                AIZ.plugins.notify('danger', 'Please select year');
                return false;
            }

            if (employee_id.length == 0) {
                AIZ.plugins.notify('danger', 'Please select employees');
                return false;
            }

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type:"POST",
                url:'<?php echo e(route('monthly.payslip.report')); ?>',
                data: {
                    'month': month,
                    'year': year,
                    'employee_id': employee_id
                },
                xhrFields: {
                    responseType: 'blob'
                },
                success: function(data) {
                    var blob=new Blob([data]);
                    var link=document.createElement('a');
                    link.href=window.URL.createObjectURL(blob);
                    var currentdate = new Date();
                    link.download="monthly_payslip_report.pdf";
                    link.click();
                },
                error: function(blob){
                    console.log(blob);
                }
            });
        });
    });
</script>

<style>
    .FixedHeightContainer
    {
        float:right;
        height: 348px;
        width:100%;
        padding:3px;
        background:#ffc519;
    }
    .Content
    {
        height:342px;
        overflow:auto;
        background:#fff;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/salary_reports/monthly_payslip.blade.php ENDPATH**/ ?>