

<?php $__env->startSection('content'); ?>

<!-- get Attendance -->
<div class="row">
    <div class="col-lg-10 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5>Salary Settings</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>SL</th>
                            <th>Gross Salry</th>
                            <th>Basic Salary</th>
                            <th>House Rent</th>
                            <th>Medicale</th>
                            <th>Transport</th>
                            <th>Food</th>
                            <th class="text-right">Options</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $salary_settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salary_setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($salary_setting->gross_salary); ?> %</td>
                            <td><?php echo e($salary_setting->basic_salary); ?> %</td>
                            <td><?php echo e($salary_setting->house_rent); ?> %</td>
                            <td><?php echo e($salary_setting->medical_allowance); ?> %</td>
                            <td><?php echo e($salary_setting->transport_allowance); ?> %</td>
                            <td><?php echo e($salary_setting->food_allowance); ?> %</td>
                            <td class="text-right">
                            <a class="btn btn-soft-primary btn-icon btn-circle btn-sm" href="<?php echo e(route('salary_settings.edit', $salary_setting->id)); ?>" title="Edit">
                                <i class="las la-edit"></i>
                            </a>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/software_settings/salary_settings/index.blade.php ENDPATH**/ ?>