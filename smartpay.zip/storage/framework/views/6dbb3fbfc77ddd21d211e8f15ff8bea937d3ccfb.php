<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0 h6">Company Information</h5>
                <div class="col text-right">
                    <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-circle btn-info">
                        <i class="las la-chevron-left"></i>
                        Back
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <form class="p-4" action="<?php echo e(route('companies.update', $company->id)); ?>" method="POST" enctype="multipart/form-data">
                    <input name="_method" type="hidden" value="PATCH">
                	<?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Full Name</label>
                        <div class="col-md-9">
                            <input type="text" name="company_full_name" value="<?php echo e($company->company_full_name); ?>" class="form-control" id="name" placeholder="Company Full Name" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">short name</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" name="company_short_name" value="<?php echo e($company->company_short_name); ?>" placeholder="Company short name">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Owner name</label>
                        <div class="col-md-9">
                            <input type="text" name="owner_name" value="<?php echo e($company->owner_name); ?>" class="form-control" id="name" placeholder="Owner name" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Phone</label>
                        <div class="col-md-9">
                            <input type="text" name="phone" value="<?php echo e($company->phone); ?>" class="form-control" id="phone" placeholder="Phone" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Email</label>
                        <div class="col-md-9">
                            <input type="text" name="email" value="<?php echo e($company->email); ?>" class="form-control" id="email" placeholder="Email" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Website</label>
                        <div class="col-md-9">
                            <input type="text" name="website" value="<?php echo e($company->website); ?>" class="form-control" id="website" placeholder="Website" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Address</label>
                        <div class="col-md-9">
                            <textarea name="address" rows="5" class="form-control"><?php echo e($company->address); ?></textarea>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Status</label>
                        <div class="col-md-9">
                            <select name="status" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                <option value="active" <?php if($company->status == 'active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="inactive" <?php if($company->digital == 'inactive'): ?> selected <?php endif; ?>>Inactive</option>
                            </select>
                        </div>
                    </div>



                    <div class="form-group mb-0 text-right">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/software_settings/companies/edit.blade.php ENDPATH**/ ?>