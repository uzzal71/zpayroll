<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0 h6">Employee Promotion Create</h5>
                <div class="col-md-6 text-md-right">
                    <a href="<?php echo e(route('employee_promotions.index')); ?>" class="btn btn-primary">
                        <i class="las la-chevron-left"></i>
                         Back
                    </a>
                </div>
            </div>
            <div class="card-body">
                <!-- Search Form -->
                <form class="" id="sort_employee_leaves" action="" method="GET" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="box-inline pad-rgt pull-left">
                        <div class="" style="min-width: 200px;">
                            <input type="text" class="form-control" id="search" name="search" <?php if(isset($sort_search)): ?> value="<?php echo e($sort_search); ?>" <?php endif; ?> placeholder="Type Employee Card & Enter">
                        </div>
                    </div>
                </form>
                <!-- Search Form -->
            </div>
        </div>

        <!-- Form Card -->
        <?php if(!empty($employee)): ?>
        <div class="card">
            <div class="card-body">
                <form class="form-horizontal" action="<?php echo e(route('employee_promotions.store')); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Employee Name</label>
                        <div class="col-md-9">
                            <input type="text" name="employee_name" id="employee_name" class="form-control" value="<?php echo e($employee->employee_name); ?>" required>
                            <input type="hidden" name="employee_id" id="employee_id" value="<?php echo e($employee->id); ?>" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Department Name</label>
                        <div class="col-md-9">
                           <select class="form-control aiz-selectpicker" name="department_id" id="department_id" data-live-search="true" required>
                                <option value="">Select Department</option>
                                <?php $__currentLoopData = \App\Models\Department::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php if($employee->department_id == $department->id): ?> selected <?php endif; ?>><?php echo e($department->department_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Designation Name</label>
                        <div class="col-md-9">
                           <select class="form-control aiz-selectpicker" name="designation_id" id="designation_id" data-live-search="true" required>
                                <option value="">Select Designation</option>
                                <?php $__currentLoopData = \App\Models\Designation::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($designation->id); ?>" <?php if($employee->designation_id == $designation->id): ?> selected <?php endif; ?>><?php echo e($designation->designation_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Effective Date</label>
                        <div class="col-md-9">
                            <input type="text" placeholder="xxxx-xx-xx" id="effective_date" name="effective_date" class="form-control" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Remarks</label>
                        <div class="col-md-9">
                            <textarea class="aiz-text-editor" name="remarks" placeholder="Remarks" required></textarea>
                        </div>
                    </div>
                    

                    <div class="form-group mb-0 text-right">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        <!-- Form Card -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/hr_management/employee_promotion/create.blade.php ENDPATH**/ ?>