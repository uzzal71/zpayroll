<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0 h6">Upload File Edit</h5>
            </div>
            <div class="card-body p-0">
                <form class="p-4" action="<?php echo e(route('upload.update', $upload->id)); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <input name="_method" type="hidden" value="PATCH">
                	<?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Month</label>
                        <div class="col-md-9">
                            <select name="attendance_month" id="attendance_month" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                <option value="January" <?php if("January" == $upload->attendance_month): ?> selected <?php endif; ?>>January</option>
                                <option value="February" <?php if("February" == $upload->attendance_month): ?> selected <?php endif; ?>>February</option>
                                <option value="March" <?php if("March" == $upload->attendance_month): ?> selected <?php endif; ?>>March</option>
                                <option value="April" <?php if("April" == $upload->attendance_month): ?> selected <?php endif; ?>>April</option>
                                <option value="May" <?php if("May" == $upload->attendance_month): ?> selected <?php endif; ?>>May</option>
                                <option value="June" <?php if("June" == $upload->attendance_month): ?> selected <?php endif; ?>>June</option>
                                <option value="July" <?php if("July" == $upload->attendance_month): ?> selected <?php endif; ?>>July</option>
                                <option value="August" <?php if("August" == $upload->attendance_month): ?> selected <?php endif; ?>>August</option>
                                <option value="September" <?php if("September" == $upload->attendance_month): ?> selected <?php endif; ?>>September</option>
                                <option value="October" <?php if("October" == $upload->attendance_month): ?> selected <?php endif; ?>>October</option>
                                <option value="November" <?php if("November" == $upload->attendance_month): ?> selected <?php endif; ?>>November</option>
                                <option value="December" <?php if("December" == $upload->attendance_month): ?> selected <?php endif; ?>>December</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Year</label>
                        <div class="col-md-9">
                            <select name="attendance_year" id="attendance_year" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                 <option value="2021" <?php if(2021 == $upload->attendance_year): ?> selected <?php endif; ?>>2021</option>
                                <option value="2022" <?php if(2022 == $upload->attendance_year): ?> selected <?php endif; ?>>2022</option>
                                <option value="2023" <?php if(2023 == $upload->attendance_year): ?> selected <?php endif; ?>>2023</option>
                                <option value="2024" <?php if(2024 == $upload->attendance_year): ?> selected <?php endif; ?>>2024</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Select Upload Excel</label>
                        <div class="col-md-9">
                            <input type="file" placeholder="Upload File Name" id="upload_file_name" name="upload_file_name" class="form-control">
                            <input type="hidden" name="old_upload_file_name" value="<?php echo e($upload->upload_path); ?>">
                        </div>
                    </div>

                    <div class="form-group mb-0 text-right">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/payroll/edit.blade.php ENDPATH**/ ?>