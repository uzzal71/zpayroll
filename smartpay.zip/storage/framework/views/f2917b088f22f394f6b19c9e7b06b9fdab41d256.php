<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0 h6">Other Payment Edit</h5>
                <div class="col-md-6 text-md-right">
                    <a href="<?php echo e(route('other_payments.index')); ?>" class="btn btn-primary">
                        <i class="las la-chevron-left"></i>
                         Back
                    </a>
                </div>
            </div>
            <div class="card-body">
                <form class="form-horizontal" action="<?php echo e(route('other_payments.update', $other_payment->id)); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <input name="_method" type="hidden" value="PATCH">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Employee Name</label>
                        <div class="col-md-9">
                            <input type="text" name="employee_name" id="employee_name" class="form-control" value="<?php echo e($other_payment->employee->employee_name); ?>" required>
                            <input type="hidden" name="employee_id" id="employee_id" value="<?php echo e($other_payment->employee_id); ?>" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Month</label>
                        <div class="col-md-9">
                            <select name="payment_month" id="payment_month" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                <option value="January" <?php if("January" == $other_payment->payment_month): ?> selected <?php endif; ?>>January</option>
                                <option value="February" <?php if("February" == $other_payment->payment_month): ?> selected <?php endif; ?>>February</option>
                                <option value="March" <?php if("March" == $other_payment->payment_month): ?> selected <?php endif; ?>>March</option>
                                <option value="April" <?php if("April" == $other_payment->payment_month): ?> selected <?php endif; ?>>April</option>
                                <option value="May" <?php if("May" == $other_payment->payment_month): ?> selected <?php endif; ?>>May</option>
                                <option value="June" <?php if("June" == $other_payment->payment_month): ?> selected <?php endif; ?>>June</option>
                                <option value="July" <?php if("July" == $other_payment->payment_month): ?> selected <?php endif; ?>>July</option>
                                <option value="August" <?php if("August" == $other_payment->payment_month): ?> selected <?php endif; ?>>August</option>
                                <option value="September" <?php if("September" == $other_payment->payment_month): ?> selected <?php endif; ?>>September</option>
                                <option value="October" <?php if("October" == $other_payment->payment_month): ?> selected <?php endif; ?>>October</option>
                                <option value="November" <?php if("November" == $other_payment->payment_month): ?> selected <?php endif; ?>>November</option>
                                <option value="December" <?php if("December" == $other_payment->payment_month): ?> selected <?php endif; ?>>December</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Year</label>
                        <div class="col-md-9">
                            <select name="payment_year" id="payment_year" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                 <option value="2021" <?php if(2021 == $other_payment->payment_year): ?> selected <?php endif; ?>>2021</option>
                                <option value="2022" <?php if(2022 == $other_payment->payment_year): ?> selected <?php endif; ?>>2022</option>
                                <option value="2023" <?php if(2023 == $other_payment->payment_year): ?> selected <?php endif; ?>>2023</option>
                                <option value="2024" <?php if(2024 == $other_payment->payment_year): ?> selected <?php endif; ?>>2024</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Amount</label>
                        <div class="col-md-9">
                            <input type="number" class="form-control" name="amount" id="amount" value="<?php echo e($other_payment->amount); ?>" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Year</label>
                        <div class="col-md-9">
                            <select name="status" id="status" required class="form-control aiz-selectpicker mb-2 mb-md-0">
                                 <option value="Plus" <?php if("Plus" == $other_payment->status): ?> selected <?php endif; ?>>Plus</option>
                                <option value="Minus" <?php if("Minus" == $other_payment->status): ?> selected <?php endif; ?>>Minus</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group mb-0 text-right">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/payment_management/other_payments/edit.blade.php ENDPATH**/ ?>