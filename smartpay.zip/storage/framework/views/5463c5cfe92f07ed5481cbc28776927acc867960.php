<?php $__env->startSection('content'); ?>
<div class="aiz-titlebar text-left mt-2 mb-3">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h1 class="h3">All Salary Increment</h1>
        </div>
        <div class="col-md-6 text-md-right">
            <a href="<?php echo e(route('salary_increments.create')); ?>" class="btn btn-primary">
                <span>Add New Increment</span>
            </a>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-header d-block d-md-flex">
        <h5 class="mb-0 h6">Salary Increments</h5>
        <form class="" id="sort_categories" action="" method="GET" autocomplete="off">
            <div class="box-inline pad-rgt pull-left">
                <div class="" style="min-width: 200px;">
                    <input type="text" class="form-control" id="search" name="search"<?php if(isset($sort_search)): ?> value="<?php echo e($sort_search); ?>" <?php endif; ?> placeholder="Type name & Enter">
                </div>
            </div>
        </form>
    </div>
    <div class="card-body">
        <table class="table aiz-table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Gross</th>
                    <th>Basic</th>
                    <th>House</th>
                    <th>Medical</th>
                    <th>Transport</th>
                    <th>Food</th>
                    <th>Effective</th>
                    <th>Remarks</th>
                    <th class="text-right">Options</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $salary_increments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $increment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(($key+1) + ($salary_increments->currentPage() - 1)*$salary_increments->perPage()); ?></td>
                        <td>
                            <?php echo e($increment->employee->employee_name); ?>

                            (<?php echo e($increment->employee->employee_punch_card); ?>)
                        </td>
                        <td><?php echo e($increment->gross_salary); ?></td>
                        <td><?php echo e($increment->basic_salary); ?></td>
                        <td><?php echo e($increment->house_rent); ?></td>
                        <td><?php echo e($increment->medical_allowance); ?></td>
                        <td><?php echo e($increment->transport_allowance); ?></td>
                        <td><?php echo e($increment->food_allowance); ?></td>
                        <td><?php echo e($increment->effective_date); ?></td>
                        <td><?php echo $increment->remarks; ?></td>
                        <td class="text-right">
                            <a class="btn btn-soft-primary btn-icon btn-circle btn-sm" href="<?php echo e(route('salary_increments.edit', $increment->id)); ?>" title="Edit">
                                <i class="las la-edit"></i>
                            </a>
                            <a href="#" class="btn btn-soft-danger btn-icon btn-circle btn-sm confirm-delete" data-href="<?php echo e(route('salary_increments.destroy', $increment->id)); ?>" title="Delete">
                                <i class="las la-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="aiz-pagination">
            <?php echo e($salary_increments->appends(request()->input())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modals.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/hr_management/salary_increment/index.blade.php ENDPATH**/ ?>