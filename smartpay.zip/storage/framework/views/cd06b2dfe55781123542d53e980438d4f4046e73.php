<?php $__env->startSection('content'); ?>
<div class="aiz-titlebar text-left mt-2 mb-3">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h1 class="h3">Employee View</h1>
        </div>
        <div class="col-md-6 text-md-right">
            <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-primary">
                <i class="las la-chevron-left"></i>
                 Back
            </a>
        </div>
    </div>
</div>


<div class="">
    <div class="row gutters-5">
            <div class="col-lg-8">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="added_by" value="admin">

                <!-- Employee Information -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Employee Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Employee Name <span class="text-danger">*</span></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="employee_name" placeholder="Employee Name" value="<?php echo e($employee->employee_name); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Employee Id Card <span class="text-danger">*</span></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="employee_id_card" placeholder="Employee Id Card" value="<?php echo e($employee->employee_id_card); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Employee Punch Card <span class="text-danger">*</span></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="employee_punch_card" placeholder="Employee Punch Card" value="<?php echo e($employee->employee_punch_card); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Mobile <span class="text-danger">*</span></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="mobile" placeholder="Mobile" value="<?php echo e($employee->mobile); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Email </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="email" placeholder="Email" value="<?php echo e($employee->email); ?>" >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">NID </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="nid" placeholder="NID" value="<?php echo e($employee->nid); ?>" >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Date Of Birth</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="date_of_birth" placeholder="Date Of Birth" value="<?php echo e($employee->date_of_birth); ?>" >
                            </div>
                        </div>

                        <div class="form-group row" id="brand">
                            <label class="col-md-3 col-from-label">Religion</label>
                            <div class="col-md-8">
                                <select class="form-control aiz-selectpicker" name="religion" id="religion" data-live-search="true">
                                    <option value="N/A">Select Religion</option>
                                    <option value="Islam" <?php if($employee->religion == 'Islam'): ?> selected <?php endif; ?>>Islam</option>
                                    <option value="Hinduism" <?php if($employee->religion == 'Hinduism'): ?> selected <?php endif; ?>>Hinduism</option>
                                    <option value="Buddhism" <?php if($employee->religion == 'Buddhism'): ?> selected <?php endif; ?>>Buddhism</option>
                                    <option value="Christianity" <?php if($employee->religion == 'Christianity'): ?> selected <?php endif; ?>>Christianity</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row" id="brand">
                            <label class="col-md-3 col-from-label">Sex</label>
                            <div class="col-md-8">
                                <select class="form-control aiz-selectpicker" name="sex" id="sex" data-live-search="true">
                                    <option value="N/A">Select Sex</option>
                                    <option value="Male" <?php if($employee->sex == 'Male'): ?> selected <?php endif; ?>>Male</option>
                                    <option value="Female" <?php if($employee->sex == 'Female'): ?> selected <?php endif; ?>>Female</option>
                                    <option value="Other" <?php if($employee->sex == 'Other'): ?> selected <?php endif; ?>>Other</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row" id="brand">
                            <label class="col-md-3 col-from-label">Marital Status</label>
                            <div class="col-md-8">
                                <select class="form-control aiz-selectpicker" name="marital_status" id="marital_status" data-live-search="true">
                                    <option value="N/A">Select Marital Status</option>
                                    <option value="Married" <?php if($employee->marital_status == 'Married'): ?> selected <?php endif; ?>>Married</option>
                                    <option value="Unmarried" <?php if($employee->marital_status == 'Unmarried'): ?> selected <?php endif; ?>>Unmarried</option>
                                </select>
                            </div>
                        </div>


                        <div class="form-group row" id="brand">
                            <label class="col-md-3 col-from-label">Blood group</label>
                            <div class="col-md-8">
                                <select class="form-control aiz-selectpicker" name="blood_group" id="blood_group" data-live-search="true">
                                <option value="N/A">Select Blood Group</option>
                                <?php $__currentLoopData = \App\Models\BloodGroup::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blood_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($blood_group->title); ?>" <?php if($blood_group->title == $employee->blood_group): ?> selected <?php endif; ?>><?php echo e($blood_group->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>


                        <div class="form-group row" id="brand">
                            <label class="col-md-3 col-from-label">Employee Status</label>
                            <div class="col-md-8">
                                <select class="form-control aiz-selectpicker" name="employee_status" id="employee_status" data-live-search="true">
                                    <option value="N/A">Select Sex</option>
                                    <option value="Regular" <?php if($employee->employee_status == 'Regular'): ?> selected <?php endif; ?>>Regular</option>
                                    <option value="New" <?php if($employee->employee_status == 'New'): ?> selected <?php endif; ?>>New</option>
                                    <option value="Left" <?php if($employee->employee_status == 'Left'): ?> selected <?php endif; ?>>Left</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Joining Date</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="joining_date" placeholder="Date Of Birth" value="<?php echo e($employee->joining_date); ?>" >
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Employee Information -->

                <!-- Family Information -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Family Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Father Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="father_name" placeholder="Father Name" value="<?php echo e($employee->father_name); ?>" >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Mother Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="mother_name" placeholder="Mother Name" value="<?php echo e($employee->mother_name); ?>" >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Emergency Contact Person Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="emergency_contact_person_name" placeholder="Emergency Contact Person Name" value="<?php echo e($employee->emergency_contact_person_name); ?>" >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Emergency Contact Person Number </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="emergency_contact_person_number" placeholder="Emergency Contact Person Number" value="<?php echo e($employee->emergency_contact_person_number); ?>" >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Present Address </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="present_address" placeholder="Present Address" value="<?php echo e($employee->present_address); ?>" >
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Permanent Address </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="permanent_address" placeholder="Permanent Address" value="<?php echo e($employee->permanent_address); ?>" >
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Family Information -->

                <!-- Bank Information -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Bank Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Account Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="account_name" placeholder="Account Name" value="<?php echo e($employee->bank->account_name); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Account Number </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="account_number" placeholder="Account Number" value="<?php echo e($employee->bank->account_number); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Bank Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="bank_name" placeholder="Bank Name" value="<?php echo e($employee->bank->bank_name); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Branch Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="bank_branch_name" placeholder="Branch Name" value="<?php echo e($employee->bank->bank_branch_name); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Bank Address </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="bank_address" placeholder="Bank Address" value="<?php echo e($employee->bank->bank_address); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Swift Code </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="swift_code" placeholder="Swift Code" value="<?php echo e($employee->bank->swift_code); ?>">
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Bank Information -->

                <!-- Last Education Information -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Last Education Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Last Degree Title </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="degree_title" placeholder="Last Degree Title" value="<?php echo e($employee->education->degree_title); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Faculty </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="faculty" placeholder="Faculty" value="<?php echo e($employee->education->faculty); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Institute Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="institute_name" placeholder="Institute Name" value="<?php echo e($employee->education->institute_name); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Duration </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="duration" placeholder="Duration" value="<?php echo e($employee->education->duration); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Passing Year </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="passing_year" placeholder="Passing Year" value="<?php echo e($employee->education->passing_year); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Result </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="result" placeholder="Result" value="<?php echo e($employee->education->result); ?>">
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Last Education Information -->

                <!-- Last Experience Information -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Last Experience Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Designation Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="designation_name" placeholder="Designation Name" value="<?php echo e($employee->experience->designation_name); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Company Name </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="company_name" placeholder="Company Name" value="<?php echo e($employee->experience->company_name); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Duration </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="duration" placeholder="Duration" value="<?php echo e($employee->experience->duration); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Location </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="location" placeholder="Location" value="<?php echo e($employee->experience->location); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label">Description </label>
                            <div class="col-md-8">
                            <textarea class="aiz-text-editor" name="description"><?php echo e($employee->experience->description); ?></textarea>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Last Experience Information -->

                <!-- Employee Images -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Employee Images</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label" for="signinSrEmail">Images <small>(600x600)</small></label>
                            <div class="col-md-8">
                                <input type="file" name="employee_photo" class="selected-files">
                                <input type="hidden" name="old_employee_photo" value="<?php echo e($employee->employee_photo); ?>" >
                                <br />
                                <small class="text-muted">These images are visible in employee details page. Use 600x600 sizes images.</small>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Employee Images -->

            </div>

            <div class="col-lg-4">

                <!-- Salary Information -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Salary Information</h5>
                    </div>

                    <div class="card-body">

                        <div class="form-group row">
                            <label class="col-md-4 col-from-label">Gross</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="gross_salary" placeholder="0.00" value="<?php echo e($employee->salary->gross_salary); ?>">
                            </div>
                        </div>


                        <div class="form-group row">
                            <label class="col-md-4 col-from-label">Basic</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="basic_salary" placeholder="0.00" value="<?php echo e($employee->salary->basic_salary); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-4 col-from-label">House Rent</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="house_rent" placeholder="0.00" value="<?php echo e($employee->salary->house_rent); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-4 col-from-label">Medical</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="medical_allowance" placeholder="0.00" value="<?php echo e($employee->salary->medical_allowance); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-4 col-from-label">Transport</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="transport_allowance" placeholder="0.00" value="<?php echo e($employee->salary->transport_allowance); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-4 col-from-label">Food</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="food_allowance" placeholder="0.00" value="<?php echo e($employee->salary->food_allowance); ?>">
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Salary Information -->

                <!-- Department -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Department</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="department_id" id="department_id" data-live-search="true" required>
                                <option value="">Select Department</option>
                                <?php $__currentLoopData = \App\Models\Department::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php if($department->id == $employee->department_id): ?> selected <?php endif; ?>><?php echo e($department->department_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Department -->

                <!-- Designation -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Designation</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="designation_id" id="designation_id" data-live-search="true" required>
                                <option value="">Select Designation</option>
                                <?php $__currentLoopData = \App\Models\Designation::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($designation->id); ?>" <?php if($designation->id == $employee->designation_id): ?> selected <?php endif; ?>><?php echo e($designation->designation_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Designation -->

                <!-- Schedule -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Duty Schedule</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="schedule_id" id="schedule_id" data-live-search="true" required>
                                <option value="">Select Schedule</option>
                                <?php $__currentLoopData = \App\Models\Schedule::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($schedule->id); ?>" <?php if($schedule->id == $employee->schedule_id): ?> selected <?php endif; ?>><?php echo e($schedule->schedule_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Schedule -->

                <!-- Tax Status -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Tax Status</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="tax_status" id="tax_status" data-live-search="true" required>
                                <option value="0" <?php if($employee->tax_status == 0): ?> selected <?php endif; ?>>No</option>
                                <option value="1" <?php if($employee->tax_status == 1): ?> selected <?php endif; ?>>Yes</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Tax Status -->

                <!-- Provident found -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Provident Found</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="provident_found_status" id="provident_found_status" data-live-search="true" required>
                                <option value="0" <?php if($employee->provident_found_status == 0): ?> selected <?php endif; ?>>No</option>
                                <option value="1" <?php if($employee->provident_found_status == 1): ?> selected <?php endif; ?>>Yes</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Provident found -->

                <!-- Transport allowance -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Transport Allowance</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="transport_allowance_status" id="transport_allowance_status" data-live-search="true" required>
                                <option value="0" <?php if($employee->transport_allowance_status == 0): ?> selected <?php endif; ?>>No</option>
                                <option value="1" <?php if($employee->transport_allowance_status == 1): ?> selected <?php endif; ?>>Yes</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Transport allowance -->

                <!-- Commission -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Commission Allowance</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="commission_status" id="commission_status" data-live-search="true" required>
                                <option value="0" <?php if($employee->commission_status == 0): ?> selected <?php endif; ?>>No</option>
                                <option value="1" <?php if($employee->commission_status == 1): ?> selected <?php endif; ?>>Yes</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Commission -->

                <!-- Salary Withdraw -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Salary Withdraw</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="salary_withdraw" id="salary_withdraw" data-live-search="true" required>
                                <option value="cash" <?php if($employee->salary_withdraw == 'cash'): ?> selected <?php endif; ?>>Cash</option>
                                <option value="bank" <?php if($employee->salary_withdraw == 'bank'): ?> selected <?php endif; ?>>Bank</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Salary Withdraw -->

                <!-- Employee Status -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6">Employee Status</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <select class="form-control aiz-selectpicker" name="status" id="status" data-live-search="true" required>
                                <option value="active" <?php if($employee->status == 'active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="inactive" <?php if($employee->status == 'inactive'): ?> selected <?php endif; ?>>inactive</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- Employee Status -->
            </div>
        </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/employees/show.blade.php ENDPATH**/ ?>