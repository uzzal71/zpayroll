<?php $__env->startSection('content'); ?>
<div class="aiz-titlebar text-left mt-2 mb-3">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h1 class="h3">All Uplaod</h1>
        </div>
        <div class="col-md-6 text-md-right">
            <a href="<?php echo e(route('upload.create')); ?>" class="btn btn-primary">
                <span>Add New Upload</span>
            </a>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-header d-block d-md-flex">
        <h5 class="mb-0 h6">Uploads</h5>
        <form class="" id="sort_categories" action="" method="GET" autocomplete="off">
            <div class="box-inline pad-rgt pull-left">
                <div class="" style="min-width: 200px;">
                    <input type="text" class="form-control" id="search" name="search"<?php if(isset($sort_search)): ?> value="<?php echo e($sort_search); ?>" <?php endif; ?> placeholder="Type Year & Enter">
                </div>
            </div>
        </form>
    </div>
    <div class="card-body">
        <table class="table aiz-table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Attendance Month</th>
                    <th>Attendance Year</th>
                    <th>Uplaod Path</th>
                    <th>Process Status</th>
                    <th class="text-right">Options</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $upload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(($key+1) + ($uploads->currentPage() - 1)*$uploads->perPage()); ?></td>
                        <td><?php echo e($upload->attendance_month); ?></td>
                        <td><?php echo e($upload->attendance_year); ?></td>
                        <td><?php echo e($upload->upload_path); ?></td>
                        <td><?php echo e($upload->process_status == 1 ? 'Please Waiting, Your file is processing' : 'File process complete'); ?></td>
                        <td class="text-right">
                            <a class="btn btn-soft-primary btn-icon btn-circle btn-sm" href="<?php echo e(route('upload.edit', $upload->id)); ?>" title="Edit">
                                <i class="las la-edit"></i>
                            </a>
                            <a href="#" class="btn btn-soft-danger btn-icon btn-circle btn-sm confirm-delete" data-href="<?php echo e(route('upload.destroy', $upload->id)); ?>" title="Delete">
                                <i class="las la-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="aiz-pagination">
            <?php echo e($uploads->appends(request()->input())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modals.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/payroll/index.blade.php ENDPATH**/ ?>