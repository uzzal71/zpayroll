

<?php $__env->startSection('content'); ?>

<!-- get Attendance -->
<?php if(isset($attendances)): ?>
<div class="row">
    <div class="col-lg-10 mx-auto">
        <div class="card">
            <div class="card-header">
                <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                      <h5 class="card-title mt-3">Attendance Approval</h5>
                    </div>
                    <div class="col-sm-6">
                        <form class="form-horizontal" id="search_form" action="<?php echo e(route('approval.attendance')); ?>" method="GET" enctype="multipart/form-data" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <input type="text" class="form-control mt-2" id="search" name="search" <?php if(isset($sort_search)): ?> value="<?php echo e($sort_search); ?>" <?php endif; ?> placeholder="Type Card Id & Enter">
                    </form>
                    </div>
                </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" class="check-all">
                            </th>
                            <th>Card Id</th>
                            <th>Date</th>
                            <th>In</th>
                            <th>Out</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="check-one" name="attendance_date[]" value="<?php echo e($attendance->attendance_date); ?>:<?php echo e($attendance->employee_id); ?>" id="attendance_date[]">
                            </td>
                            <td><?php echo e($attendance->employee_id); ?></td>
                            <td><?php echo e($attendance->attendance_date); ?></td>
                            <td><?php echo e($attendance->attendance_in); ?></td>
                            <td><?php echo e($attendance->attendance_out); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <!-- Button start -->
                <div class="form-group mb-0 text-right">
                    <button type="button" class="btn btn-primary" id="attendance_approval_save">Save</button>
                </div>
                <!-- Button start -->
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$(document).on("change", ".check-all", function() {
    if(this.checked) {
        // Iterate each checkbox
        $('.check-one:checkbox').each(function() {
            this.checked = true;
        });
    } else {
        $('.check-one:checkbox').each(function() {
            this.checked = false;
        });
    }
});

$(document).ready(function() {
    $('#attendance_approval_save').click(function() {

        var attendance_date = [];

        $.each($("input[type=checkbox].check-one:checked"), function(){
            attendance_date.push($(this).val());
        });

        if (attendance_date.length == 0) {
            AIZ.plugins.notify('danger', 'Please select employees');
            return false;
        }

        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type:"POST",
            url:'<?php echo e(route('approval.attendance.save')); ?>',
            data: {
                'attendance_date': attendance_date
            },
            success: function(data) {
                AIZ.plugins.notify('success', 'Attendance approval');

                setTimeout(() => {
                    if(data.redirect_url){
                       window.location = data.redirect_url;
                    }
                }, 1000);
            }
        });
    });
});
</script>

<style type="text/css">
    .form-customer {
        width: 90px !important;
        text-align: center !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/payroll/approval_attendance.blade.php ENDPATH**/ ?>