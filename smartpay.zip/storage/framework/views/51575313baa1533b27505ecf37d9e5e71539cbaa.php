

<?php $__env->startSection('content'); ?>

<div class="aiz-titlebar text-left mt-2 mb-3">
    <div class="row align-items-center">
        <div class="col-auto">
            <h1 class="h3">All employees</h1>
        </div>
        <div class="col text-right">
            <a href="<?php echo e(route('employees.create')); ?>" class="btn btn-circle btn-info">
                <span>Add New Employee</span>
            </a>
        </div>
    </div>
</div>
<br>

<div class="card">
        <div class="card-header row gutters-5">
            <div class="col">
                <h5 class="mb-md-0 h6">All Employee</h5>
            </div>
            
            <div class="dropdown mb-2 mb-md-0">
                <button class="btn border dropdown-toggle" type="button" data-toggle="dropdown">
                    Bulk Action
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="#"> Delete selection</a>
                </div>
            </div>

            <!-- Deepartment Search -->
            <div class="col-md-2 ml-auto">
                <select class="form-control form-control-sm aiz-selectpicker mb-2 mb-md-0" id="user_id" name="user_id" onchange="sort_products()">
                    <option value="">All Department</option>
                    <?php $__currentLoopData = App\Models\Department::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->department_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <!-- Deepartment Search -->

            <!-- Designation Search -->
            <div class="col-md-2 ml-auto">
                <select class="form-control form-control-sm aiz-selectpicker mb-2 mb-md-0" id="user_id" name="user_id" onchange="sort_products()">
                    <<option value="">All Designation</option>
                    <?php $__currentLoopData = App\Models\Designation::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($designation->id); ?>"><?php echo e($designation->designation_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <!-- Designation Search -->
            
        </div>
    
        <div class="card-body">
            <table class="table aiz-table mb-0">
                <thead>
                    <tr>
                        <th>
                            <div class="form-group">
                                <div class="aiz-checkbox-inline">
                                    <label class="aiz-checkbox">
                                        <input type="checkbox" class="check-all">
                                        <span class="aiz-square-check"></span>
                                    </label>
                                </div>
                            </div>
                        </th>
                        <th>#</th>
                        <th>Name</th>
                        <th>Id</th>
                        <th>Card</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th>Schedule</th>
                        <th>Options</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="form-group d-inline-block">
                                <label class="aiz-checkbox">
                                    <input type="checkbox" class="check-one" name="id[]" value="<?php echo e($employee->id); ?>">
                                    <span class="aiz-square-check"></span>
                                </label>
                            </div>
                        </td>
                        <td><?php echo e(($key+1) + ($employees->currentPage() - 1)*$employees->perPage()); ?></td>
                        <td>
                            <div class="row gutters-5 w-200px w-md-200px mw-100">
                                <div class="col-auto">
                                    <img src="<?php echo e(static_asset('assets/img/avatar-place.png')); ?>" alt="Image" class="size-50px img-fit">
                                </div>
                                <div class="col">
                                    <span class="text-muted text-truncate-2"><?php echo e($employee->employee_name); ?></span>
                                </div>
                            </div>
                        </td>

                        <td><?php echo e($employee->employee_id_card); ?></td>
                        <td><?php echo e($employee->employee_punch_card); ?></td>
                        <td><?php echo e($employee->department->department_name); ?></td>
                        <td><?php echo e($employee->designation->designation_name); ?></td>
                        <td><?php echo e($employee->schedule->schedule_name); ?></td>
                        
                        <td>

                            <a class="btn btn-soft-primary btn-icon btn-circle btn-sm" href="<?php echo e(route('employees.show', $employee->id)); ?>" title="View">
                                <i class="las la-eye"></i>
                            </a>

                            <a class="btn btn-soft-primary btn-icon btn-circle btn-sm" href="<?php echo e(route('employees.edit', $employee->id)); ?>" title="Edit">
                                <i class="las la-edit"></i>
                            </a>

                           <a href="#" class="btn btn-soft-danger btn-icon btn-circle btn-sm confirm-delete" data-href="<?php echo e(route('employees.destroy', $employee->id)); ?>" title="Delete">
                                <i class="las la-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="aiz-pagination">
                <?php echo e($employees->appends(request()->input())->links()); ?>

            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modals.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/employees/index.blade.php ENDPATH**/ ?>