<?php $__env->startSection('content'); ?>
<div class="aiz-titlebar text-left mt-2 mb-3">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h1 class="h3">All Holiday Entry</h1>
        </div>
        <div class="col-md-6 text-md-right">
            <a href="<?php echo e(route('holiday_entries.create')); ?>" class="btn btn-primary">
                <span>Add New Holiday</span>
            </a>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-header d-block d-md-flex">
        <h5 class="mb-0 h6">Holiday Entries</h5>
        <form class="" id="sort_categories" action="" method="GET">
            <div class="box-inline pad-rgt pull-left">
                <div class="" style="min-width: 200px;">
                    <input type="text" class="form-control" id="search" name="search"<?php if(isset($sort_search)): ?> value="<?php echo e($sort_search); ?>" <?php endif; ?> placeholder="Type name & Enter">
                </div>
            </div>
        </form>
    </div>
    <div class="card-body">
        <table class="table aiz-table mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Holiday name</th>
                    <th>Form date</th>
                    <th>To date</th>
                    <th>Holiday days</th>
                    <th>Remarks</th>
                    <th>Status</th>
                    <th class="text-right">Options</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $holiday_entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $holiday_entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(($key+1) + ($holiday_entries->currentPage() - 1)*$holiday_entries->perPage()); ?></td>
                        <td><?php echo e($holiday_entry->holiday_name); ?></td>
                        <td><?php echo e($holiday_entry->from_date); ?></td>
                        <td><?php echo e($holiday_entry->to_date); ?></td>
                        <td><?php echo e($holiday_entry->holiday_days); ?></td>
                        <td><?php echo e($holiday_entry->remarks); ?></td>
                        <td><?php echo e($holiday_entry->status); ?></td>
                        <td class="text-right">
                            <a class="btn btn-soft-primary btn-icon btn-circle btn-sm" href="<?php echo e(route('holiday_entries.edit', $holiday_entry->id)); ?>" title="Edit">
                                <i class="las la-edit"></i>
                            </a>
                            <a href="#" class="btn btn-soft-danger btn-icon btn-circle btn-sm confirm-delete" data-href="<?php echo e(route('holiday_entries.destroy', $holiday_entry->id)); ?>" title="Delete">
                                <i class="las la-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="aiz-pagination">
            <?php echo e($holiday_entries->appends(request()->input())->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('modals.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\zpayroll\resources\views/hr_management/holiday_entry/index.blade.php ENDPATH**/ ?>